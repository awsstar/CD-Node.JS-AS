#!/bin/bash
forever start /srv/mynodeapp/server.js

