#!/bin/bash
forever stop /srv/mynodeapp/server.js
